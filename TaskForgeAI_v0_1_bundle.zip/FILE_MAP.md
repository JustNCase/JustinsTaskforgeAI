# File Map

## Docs
- `docs/business-plan.md` — core business model
- `docs/architecture.md` — tech stack and system design
- `docs/roadmap.md` — build sequence
- `docs/monetization.md` — revenue streams

## App
- `apps/web/package.json` — Next.js app dependencies
- `apps/web/app/page.tsx` — marketing homepage
- `apps/web/app/dashboard/page.tsx` — user dashboard stub
- `apps/web/app/layout.tsx` — app shell
- `apps/web/components/*` — reusable UI
- `apps/web/lib/*` — helper functions

## Database
- `database/schema.sql` — initial Supabase schema

## Deployment
- `deployment/vercel.md` — deploy instructions
- `deployment/env.example` — environment variables
