# Architecture

## Frontend
- Next.js App Router
- TypeScript
- Tailwind CSS

## Backend
- Supabase Auth
- Supabase Postgres
- Server actions or route handlers
- Optional Stripe for paid subscriptions

## Core entities
- users
- wallets
- earnings
- withdrawals
- referrals
- business_leads
- offers
- sponsorships

## Design goals
- easy for one person to maintain
- simple deployment
- audit-friendly balance tracking
- low-cost startup
