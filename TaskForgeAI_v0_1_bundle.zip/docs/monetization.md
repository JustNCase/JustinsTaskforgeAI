# Monetization

## Stream 1: Offerwalls
Users complete third-party offers and the platform keeps a spread.

## Stream 2: Lead generation
Users submit interested prospects and businesses pay per qualified lead.

## Stream 3: Sponsored tasks
Businesses pay for photos, visits, verification, and content.

## Stream 4: Membership
Paid users get faster withdrawals and higher limits.

## Stream 5: Referrals
Growth engine that lowers acquisition cost.
