# Roadmap

## Phase 1
- repo scaffold
- homepage
- dashboard
- schema
- deployment files

## Phase 2
- signup/login
- profile
- wallet ledger
- referral code system

## Phase 3
- withdrawals
- admin panel
- offerwall hooks

## Phase 4
- business lead marketplace
- sponsored tasks
- AI verification workflows
