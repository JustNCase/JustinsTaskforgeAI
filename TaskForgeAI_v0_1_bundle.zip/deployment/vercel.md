# Vercel Deployment

1. Push the repo to GitHub.
2. Import the repo into Vercel.
3. Set environment variables.
4. Connect the Supabase project.
5. Deploy preview first, then production.

## Important env vars
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `NEXT_PUBLIC_SITE_URL`
