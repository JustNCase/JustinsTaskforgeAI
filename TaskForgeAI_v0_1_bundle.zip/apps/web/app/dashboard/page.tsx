const rows = [
  { label: "Balance", value: "$0.00" },
  { label: "Pending earnings", value: "$0.00" },
  { label: "Withdrawals", value: "0" },
  { label: "Referrals", value: "0" }
];

export default function DashboardPage() {
  return (
    <main style={{ minHeight: "100vh", padding: 48, maxWidth: 1100, margin: "0 auto" }}>
      <h1 style={{ fontSize: "3rem", marginBottom: 16 }}>Dashboard</h1>
      <p style={{ opacity: 0.8, marginBottom: 32 }}>
        This is the starter dashboard. Connect Supabase auth and wallet logic next.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
        {rows.map((row) => (
          <div key={row.label} style={{ border: "1px solid #333", borderRadius: 20, padding: 20, background: "#111" }}>
            <div style={{ opacity: 0.7 }}>{row.label}</div>
            <div style={{ fontSize: 30, marginTop: 8 }}>{row.value}</div>
          </div>
        ))}
      </div>
    </main>
  );
}
