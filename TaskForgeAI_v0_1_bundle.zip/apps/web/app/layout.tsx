import "./globals.css";

export const metadata = {
  title: "TaskForge AI",
  description: "Rewards and lead generation platform"
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
