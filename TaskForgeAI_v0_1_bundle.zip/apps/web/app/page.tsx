const stats = [
  { label: "Revenue streams", value: "5+" },
  { label: "Launch focus", value: "Solo founder" },
  { label: "Backend", value: "Supabase" },
  { label: "Frontend", value: "Next.js" }
];

export default function HomePage() {
  return (
    <main style={{ minHeight: "100vh", padding: "48px", maxWidth: 1100, margin: "0 auto" }}>
      <section style={{ display: "grid", gap: 24 }}>
        <div>
          <p style={{ textTransform: "uppercase", letterSpacing: "0.15em", opacity: 0.7 }}>TaskForge AI</p>
          <h1 style={{ fontSize: "clamp(2.5rem, 7vw, 5rem)", lineHeight: 1, margin: "12px 0" }}>
            Real revenue platform for a solo owner.
          </h1>
          <p style={{ maxWidth: 720, fontSize: "1.1rem", opacity: 0.85 }}>
            Starter homepage for a rewards, referrals, and business-leads product designed to be deployed
            as a simple web app and expanded over time.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
          {stats.map((item) => (
            <div key={item.label} style={{ border: "1px solid #333", borderRadius: 20, padding: 20, background: "#111" }}>
              <div style={{ fontSize: 14, opacity: 0.7 }}>{item.label}</div>
              <div style={{ fontSize: 28, marginTop: 8 }}>{item.value}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <a href="/dashboard" style={{ padding: "12px 18px", borderRadius: 999, background: "#fff", color: "#000", textDecoration: "none" }}>
            Open dashboard
          </a>
          <a href="#roadmap" style={{ padding: "12px 18px", borderRadius: 999, border: "1px solid #444", textDecoration: "none" }}>
            View roadmap
          </a>
        </div>
      </section>

      <section id="roadmap" style={{ marginTop: 64, display: "grid", gap: 16 }}>
        <h2 style={{ fontSize: 32 }}>Build path</h2>
        <div style={{ display: "grid", gap: 12 }}>
          <div style={{ padding: 18, border: "1px solid #333", borderRadius: 16 }}>1. Authentication and profiles</div>
          <div style={{ padding: 18, border: "1px solid #333", borderRadius: 16 }}>2. Wallet and earnings ledger</div>
          <div style={{ padding: 18, border: "1px solid #333", borderRadius: 16 }}>3. Referrals and withdrawals</div>
          <div style={{ padding: 18, border: "1px solid #333", borderRadius: 16 }}>4. Lead marketplace and admin panel</div>
        </div>
      </section>
    </main>
  );
}
