export const APP_NAME = "TaskForge AI";
