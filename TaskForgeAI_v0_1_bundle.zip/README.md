# TaskForge AI v0.1

A solo-owner rewards and lead-generation SaaS starter.

## What this bundle is
This is a repo-style starter package that gives you:
- a documented business model
- a Next.js web app scaffold
- a Supabase-ready schema
- deployment notes
- a file map so you can find everything later

## Long-term access
Keep this project in GitHub and commit every milestone:
- `v0.1` project scaffold
- `v0.2` auth
- `v0.3` wallet
- `v0.4` referrals
- `v0.5` withdrawals
- `v0.6` admin panel

## Suggested repository layout
```text
TaskForgeAI/
├── apps/
│   └── web/
├── database/
├── docs/
├── deployment/
├── assets/
└── README.md
```

## Next steps
1. Create the GitHub repo.
2. Unzip this bundle into the repo root.
3. Commit everything.
4. Deploy the web app to Vercel.
5. Connect Supabase.

## Notes
This package is a foundation, not a finished production system.
